<div class="navbar navbar-inverse navbar-fixed-top">
   
  <div class="navbar-header">
	  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	  </button>
    <a class="navbar-brand" href="home.php">Affable Beans</a>	</div>
	<div class="navbar-collapse collapse">
	  <ul class="nav navbar-nav">
		<li><a href="categorie_liste.php"><span class="glyphicon glyphicon-camera"> </span> Catégories</a></li>
        <li><a href="clients.php"><span class="glyphicon glyphicon-flag"> </span> Clients</a></li>
	  </ul>
	   <div class="navbar-form navbar-right" style="margin-right: 5px;">
		<a href="deconnexion.php" type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-remove-circle"> </span> Log out</a>
	  </div>
	</div>
    
</div>