<?php 
include("verifier_access.php");
$id_page = "dashboard";

?>
<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>The Affable Beans - Admin</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>

    <?php include('header.php'); ?>
	
    <div class="container2">
      <h1><span class="glyphicon glyphicon-dashboard"> </span> Dashboard</h1>
    </div>

    <div class="container2">   
        
        Nombre des commandes : 999 <br/>
        Nombre des clients : 999 <br/>
        Nombre des produitd : 999 <br/>

    </div>

<hr>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>

    </body>
</html>
